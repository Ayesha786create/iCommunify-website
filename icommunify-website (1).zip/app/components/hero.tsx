import { Button } from "@/components/ui/button"
import { ArrowRight, Play, Users, Calendar, Sparkles } from "lucide-react"
import Image from "next/image"

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-slate-50 via-white to-indigo-50 pt-16 pb-20 sm:pt-24 sm:pb-32">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=800&width=1200')] opacity-5"></div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-8 items-center">
          {/* Left column - Content (follows rule of thirds) */}
          <div className="lg:col-span-7 xl:col-span-6">
            <div className="max-w-2xl">
              {/* Badge */}
              <div className="inline-flex items-center rounded-full bg-indigo-100 px-4 py-2 text-sm font-medium text-indigo-700 mb-6">
                <Sparkles className="h-4 w-4 mr-2" />
                Transform Your University Experience
              </div>

              {/* Main heading */}
              <h1 className="text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl xl:text-6xl">
                Connect, Create, and
                <span className="text-indigo-600"> Celebrate</span>
                Campus Life
              </h1>

              {/* Description */}
              <p className="mt-6 text-lg leading-8 text-slate-600 max-w-xl">
                iCommunify transforms university club and event management. Discover clubs, create events, and build
                lasting connections that make your university experience unforgettable.
              </p>

              {/* CTA Buttons */}
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 text-base font-semibold shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  Start Exploring
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-slate-300 text-slate-700 hover:bg-slate-50 px-8 py-3 text-base font-semibold bg-transparent"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Watch Demo
                </Button>
              </div>

              {/* Quick stats */}
              <div className="mt-12 grid grid-cols-3 gap-4 sm:gap-8">
                <div className="text-center sm:text-left">
                  <div className="text-2xl font-bold text-slate-900">500+</div>
                  <div className="text-sm text-slate-600">Active Clubs</div>
                </div>
                <div className="text-center sm:text-left">
                  <div className="text-2xl font-bold text-slate-900">10K+</div>
                  <div className="text-sm text-slate-600">Students</div>
                </div>
                <div className="text-center sm:text-left">
                  <div className="text-2xl font-bold text-slate-900">1K+</div>
                  <div className="text-sm text-slate-600">Events Monthly</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right column - Visual (follows golden ratio) */}
          <div className="lg:col-span-5 xl:col-span-6">
            <div className="relative">
              {/* Background decoration */}
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-3xl transform rotate-3 scale-105 opacity-20"></div>

              {/* Main dashboard mockup */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl bg-white border border-slate-200">
                <Image
                  src="/images/hero-dashboard.png"
                  alt="iCommunify platform dashboard showing clubs and events"
                  width={800}
                  height={600}
                  className="w-full h-auto"
                  priority
                />

                {/* Overlay gradient for better text readability */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent"></div>
              </div>

              {/* Floating notification cards */}
              <div className="absolute -top-6 -left-6 bg-white rounded-xl shadow-lg p-4 border border-slate-200 max-w-xs">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                    <Users className="h-5 w-5 text-indigo-600" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-slate-900">Drama Club</div>
                    <div className="text-xs text-slate-600">15 new members joined</div>
                  </div>
                </div>
              </div>

              <div className="absolute -bottom-6 -right-6 bg-white rounded-xl shadow-lg p-4 border border-slate-200 max-w-xs">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-emerald-600" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-slate-900">Tech Meetup</div>
                    <div className="text-xs text-slate-600">Starting in 2 hours</div>
                  </div>
                </div>
              </div>

              {/* Additional floating element */}
              <div className="absolute top-1/2 -left-4 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full p-3 shadow-lg">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
