import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"
import Image from "next/image"

export default function Testimonials() {
  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Computer Science Student",
      university: "Tech University",
      content:
        "iCommunify helped me find the perfect coding club and made so many friends. The event management features are incredible!",
      avatar: "/placeholder.svg?height=60&width=60&text=SC",
    },
    {
      name: "Marcus Johnson",
      role: "Business Major",
      university: "State University",
      content:
        "As a club president, iCommunify streamlined our event planning and doubled our membership in just one semester.",
      avatar: "/placeholder.svg?height=60&width=60&text=MJ",
    },
    {
      name: "Emma Rodriguez",
      role: "Psychology Student",
      university: "Liberal Arts College",
      content:
        "The platform is so intuitive and accessible. I love how easy it is to discover new opportunities and connect with peers.",
      avatar: "/placeholder.svg?height=60&width=60&text=ER",
    },
  ]

  return (
    <section className="py-20 sm:py-32 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">What students are saying</h2>
          <p className="mt-4 text-lg text-slate-600">
            Real experiences from students who've transformed their university life with iCommunify
          </p>
        </div>

        {/* Testimonials grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="border-slate-200 hover:shadow-xl transition-all duration-300 group hover:-translate-y-1 relative overflow-hidden"
            >
              {/* Background gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-transparent to-slate-50/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>

              <CardContent className="p-6 relative">
                {/* Stars with animation */}
                <div className="flex space-x-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 fill-yellow-400 text-yellow-400 group-hover:scale-110 transition-transform duration-200"
                      style={{ transitionDelay: `${i * 50}ms` }}
                    />
                  ))}
                </div>

                {/* Content with better typography */}
                <p className="text-slate-600 mb-6 leading-relaxed italic">"{testimonial.content}"</p>

                {/* Author with enhanced styling */}
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Image
                      src={testimonial.avatar || "/placeholder.svg"}
                      alt={`${testimonial.name} profile picture`}
                      width={48}
                      height={48}
                      className="rounded-full ring-2 ring-slate-200 group-hover:ring-indigo-300 transition-all duration-300"
                    />
                    <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white"></div>
                  </div>
                  <div>
                    <div className="font-semibold text-slate-900 group-hover:text-indigo-900 transition-colors duration-300">
                      {testimonial.name}
                    </div>
                    <div className="text-sm text-slate-600">{testimonial.role}</div>
                    <div className="text-sm text-slate-500">{testimonial.university}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
