import { Card, CardContent } from "@/components/ui/card"
import { Users, Calendar, Search, Bell, Shield, Zap } from "lucide-react"
import Image from "next/image"

export default function Features() {
  const features = [
    {
      icon: Search,
      title: "Discover Clubs",
      description: "Find clubs that match your interests with our intelligent search and recommendation system.",
      color: "text-blue-600",
    },
    {
      icon: Calendar,
      title: "Event Management",
      description: "Create, manage, and promote events with built-in RSVP tracking and automated reminders.",
      color: "text-emerald-600",
    },
    {
      icon: Users,
      title: "Community Building",
      description: "Connect with like-minded students and build lasting relationships within your university.",
      color: "text-purple-600",
    },
    {
      icon: Bell,
      title: "Smart Notifications",
      description: "Stay updated with personalized notifications about events and club activities you care about.",
      color: "text-orange-600",
    },
    {
      icon: Shield,
      title: "Safe & Secure",
      description: "University-verified platform ensuring a safe environment for all student interactions.",
      color: "text-red-600",
    },
    {
      icon: Zap,
      title: "Instant Updates",
      description: "Real-time updates on club activities, event changes, and important announcements.",
      color: "text-yellow-600",
    },
  ]

  return (
    <section id="features" className="py-20 sm:py-32 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
            Everything you need to thrive on campus
          </h2>
          <p className="mt-4 text-lg text-slate-600">
            Powerful features designed to make university life more connected, organized, and engaging for every
            student.
          </p>
        </div>

        <div className="relative mb-16">
          {/* Background pattern */}
          <div className="absolute inset-0 opacity-5">
            <Image
              src="/images/pattern-dots.png"
              alt=""
              width={1200}
              height={400}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Feature preview images */}
          <div className="relative grid md:grid-cols-3 gap-8 mb-8">
            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-4 rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/club-discovery.png"
                  alt="Club discovery interface"
                  width={128}
                  height={128}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-semibold text-slate-900">Discover</h3>
            </div>

            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-4 rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/event-creation.png"
                  alt="Event creation interface"
                  width={128}
                  height={128}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-semibold text-slate-900">Create</h3>
            </div>

            <div className="text-center">
              <div className="relative w-32 h-32 mx-auto mb-4 rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/students-collaborating.png"
                  alt="Students collaborating"
                  width={128}
                  height={128}
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="font-semibold text-slate-900">Connect</h3>
            </div>
          </div>
        </div>

        {/* Features grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="border-slate-200 hover:shadow-lg transition-all duration-200 group hover:-translate-y-1"
            >
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div
                    className={`flex-shrink-0 p-3 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 group-hover:from-indigo-50 group-hover:to-indigo-100 transition-colors duration-200`}
                  >
                    <feature.icon
                      className={`h-6 w-6 ${feature.color} group-hover:scale-110 transition-transform duration-200`}
                    />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">{feature.title}</h3>
                    <p className="text-slate-600 leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
