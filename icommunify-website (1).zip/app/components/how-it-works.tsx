import { Card, CardContent } from "@/components/ui/card"
import { UserPlus, Search, Calendar, Users } from "lucide-react"
import Image from "next/image"

export default function HowItWorks() {
  const steps = [
    {
      step: "01",
      icon: UserPlus,
      title: "Create Your Profile",
      description: "Sign up with your university email and tell us about your interests and goals.",
      color: "bg-blue-500",
    },
    {
      step: "02",
      icon: Search,
      title: "Discover & Join",
      description: "Browse clubs and events tailored to your interests, or search for specific activities.",
      color: "bg-emerald-500",
    },
    {
      step: "03",
      icon: Calendar,
      title: "Participate & Create",
      description: "Attend events, join discussions, and even create your own events for your clubs.",
      color: "bg-purple-500",
    },
    {
      step: "04",
      icon: Users,
      title: "Build Community",
      description: "Connect with fellow students, form study groups, and create lasting friendships.",
      color: "bg-orange-500",
    },
  ]

  return (
    <section id="how-it-works" className="py-20 sm:py-32 bg-slate-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-5">
        <Image
          src="/images/pattern-waves.png"
          alt=""
          width={1200}
          height={800}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">How iCommunify Works</h2>
          <p className="mt-4 text-lg text-slate-600">
            Get started in minutes and transform your university experience with these simple steps.
          </p>
        </div>

        {/* Steps with enhanced visuals */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              {/* Connector line with animated dots */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-16 left-full w-full h-0.5 bg-gradient-to-r from-slate-300 to-slate-200 z-0">
                  <div className="absolute left-1/4 top-1/2 transform -translate-y-1/2 w-1 h-1 bg-indigo-400 rounded-full animate-pulse"></div>
                  <div className="absolute left-2/4 top-1/2 transform -translate-y-1/2 w-1 h-1 bg-indigo-300 rounded-full animate-pulse delay-300"></div>
                  <div className="absolute left-3/4 top-1/2 transform -translate-y-1/2 w-1 h-1 bg-indigo-200 rounded-full animate-pulse delay-700"></div>
                </div>
              )}

              <Card className="relative z-10 border-slate-200 hover:shadow-xl transition-all duration-300 group hover:-translate-y-2">
                <CardContent className="p-6 text-center">
                  {/* Step number with gradient background */}
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-br from-slate-100 to-slate-200 text-slate-600 font-bold text-sm mb-4 group-hover:from-indigo-100 group-hover:to-indigo-200 group-hover:text-indigo-700 transition-all duration-300">
                    {step.step}
                  </div>

                  {/* Icon with enhanced styling */}
                  <div
                    className={`inline-flex items-center justify-center w-16 h-16 rounded-full ${step.color} mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}
                  >
                    <step.icon className="h-8 w-8 text-white" />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-semibold text-slate-900 mb-2 group-hover:text-indigo-900 transition-colors duration-300">
                    {step.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed">{step.description}</p>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>

        {/* Additional visual element */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center space-x-2 text-slate-500">
            <div className="w-2 h-2 bg-indigo-300 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce delay-100"></div>
            <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce delay-200"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
