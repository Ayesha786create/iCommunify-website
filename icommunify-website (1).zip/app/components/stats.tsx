export default function Stats() {
  const stats = [
    { number: "50+", label: "Universities", description: "Across the country" },
    { number: "25K+", label: "Active Students", description: "Engaged daily" },
    { number: "500+", label: "Student Clubs", description: "And growing" },
    { number: "2K+", label: "Events Monthly", description: "Something for everyone" },
  ]

  return (
    <section className="py-20 sm:py-32 bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-700 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 bg-[url('/images/pattern-dots.png')] opacity-10"></div>
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
        <div className="absolute top-32 right-20 w-32 h-32 bg-purple-300/20 rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 left-1/4 w-24 h-24 bg-indigo-300/20 rounded-full blur-xl"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">Trusted by students nationwide</h2>
          <p className="mt-4 text-lg text-indigo-100">
            Join thousands of students who are already transforming their university experience
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center group">
              <div className="relative">
                {/* Glowing background effect */}
                <div className="absolute inset-0 bg-white/5 rounded-2xl blur-xl group-hover:bg-white/10 transition-all duration-300"></div>

                <div className="relative bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20 group-hover:bg-white/15 group-hover:scale-105 transition-all duration-300">
                  <div className="text-4xl sm:text-5xl font-bold text-white mb-2 group-hover:text-indigo-100 transition-colors duration-300">
                    {stat.number}
                  </div>
                  <div className="text-lg font-semibold text-indigo-100 mb-1">{stat.label}</div>
                  <div className="text-sm text-indigo-200">{stat.description}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Additional visual elements */}
        <div className="mt-16 flex justify-center space-x-8 opacity-60">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-white rounded-full"></div>
            <span className="text-white text-sm">Real-time data</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-indigo-300 rounded-full"></div>
            <span className="text-white text-sm">Growing daily</span>
          </div>
        </div>
      </div>
    </section>
  )
}
